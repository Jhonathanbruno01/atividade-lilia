import db from '../config/db.js';

// Mudança: SneakerModel -> PecaModel
const PecaModel = {
    // CRUD: CREATE
    // Mudança de variável e campos no objeto
    criar: async (peca) => {
        const { nome, fabricante, categoria, frequencia, preco, overclock_status, imagem_url } = peca;
        // Mudança: tabela 'sneakers' -> 'pecas' e nomes das colunas
        const sql = 'INSERT INTO pecas (nome, fabricante, categoria, frequencia, preco, overclock_status, imagem_url) VALUES (?, ?, ?, ?, ?, ?, ?)';
        const values = [nome, fabricante, categoria, frequencia, preco, overclock_status, imagem_url];
        
        const [result] = await db.query(sql, values);
        return PecaModel.buscarPorId(result.insertId);
    },

    // CRUD: READ ALL
    listarTodos: async () => {
        try {
            // Mudança: tabela 'sneakers' -> 'pecas'
            const sql = 'SELECT * FROM pecas ORDER BY id DESC';
            const [rows] = await db.query(sql);
            console.log('Dados retornados pelo banco:', rows.length);
            return rows;
        } catch (error) {
            console.error('Erro na query listarTodos:', error);
            throw error;
        }
    },

    // CRUD: READ ONE
    buscarPorId: async (id) => {
        // Mudança: tabela 'sneakers' -> 'pecas'
        const sql = 'SELECT * FROM pecas WHERE id = ?';
        const [rows] = await db.query(sql, [id]);
        return rows[0];
    },

    // CRUD: UPDATE
    // Mudança de variável e campos no objeto
    atualizar: async (id, peca) => {
        const { nome, fabricante, categoria, frequencia, preco, overclock_status, imagem_url } = peca;
        // Mudança: tabela 'sneakers' -> 'pecas' e nomes das colunas
        const sql = 'UPDATE pecas SET nome = ?, fabricante = ?, categoria = ?, frequencia = ?, preco = ?, overclock_status = ?, imagem_url = ? WHERE id = ?';
        const values = [nome, fabricante, categoria, frequencia, preco, overclock_status, imagem_url, id];
        
        const [result] = await db.query(sql, values);
        
        if (result.affectedRows > 0) {
            return PecaModel.buscarPorId(id);
        }
        return null; 
    },

    // CRUD: DELETE
    deletar: async (id) => {
        // Mudança: tabela 'sneakers' -> 'pecas'
        const sql = 'DELETE FROM pecas WHERE id = ?';
        const [result] = await db.query(sql, [id]);
        return result.affectedRows;
    }
};

// Mudança: exportar PecaModel
export default PecaModel;