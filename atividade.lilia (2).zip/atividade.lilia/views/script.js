// Carregar os produtos do backend
async function carregarProdutos() {
    const container = document.getElementById('products-container');
    container.innerHTML = "<p style='text-align:center;'>Carregando produtos...</p>";

    try {
        const response = await fetch("http://localhost:3000/products");
        const produtos = await response.json();

        container.innerHTML = "";

        produtos.forEach(produto => {
            const card = `
                <div class="product-card">
                    <img src="${produto.primary_image || 'images/default.jpg'}" alt="${produto.name}">
                    
                    <div class="product-details">
                        <h3>${produto.name}</h3>
                        <p>${produto.description || ''}</p>
                        <p class="price">R$ ${produto.price.toFixed(2)}</p>
                        <a class="btn-buy" href="#">Comprar</a>
                    </div>
                </div>
            `;
            container.innerHTML += card;
        });

    } catch (error) {
        container.innerHTML = "<p>Erro ao carregar produtos.</p>";
        console.error("Erro:", error);
    }
}

// Iniciar carregamento
window.onload = carregarProdutos;
