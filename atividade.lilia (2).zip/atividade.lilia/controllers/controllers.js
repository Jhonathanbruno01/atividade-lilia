// Mudança: importação do modelo
import Peca from '../models/models.js';

// Mudança: sneakerController -> pecaController
const pecaController = {
    async create(req, res) {
        try {
            // Mudança: Nova variável e chamada de método
            const novaPeca = await Peca.criar(req.body); 
            return res.status(201).json(novaPeca);
        } catch (error) {
            // Mudança na mensagem de erro
            return res.status(500).json({ erro: 'Erro ao criar peça.', detalhes: error.message }); 
        }
    },
    async listAll(req, res) {
        try {
            // Mudança: Nova variável e chamada de método
            const pecas = await Peca.listarTodos(); 
            return res.status(200).json(pecas);
        } catch (error) {
            // Mudança na mensagem de erro
            console.error('Erro ao listar peças:', error);
            return res.status(500).json({ erro: 'Erro ao listar peças.', detalhes: error.message });
        }
    },
    async listOne(req, res) {
        try {
            const { id } = req.params;
            // Mudança: Nova variável e chamada de método
            const peca = await Peca.buscarPorId(id); 
            // Mudança na mensagem de não encontrado
            if (!peca) return res.status(404).json({ mensagem: 'Peça não encontrada.' }); 
            return res.status(200).json(peca);
        } catch (error) {
            // Mudança na mensagem de erro
            return res.status(500).json({ erro: 'Erro ao buscar peça.', detalhes: error.message });
        }
    },
    async update(req, res) {
        try {
            const { id } = req.params;
            // Mudança: Nova variável e chamada de método
            const pecaAtualizada = await Peca.atualizar(id, req.body); 
            // Mudança na mensagem de não encontrado
            if (!pecaAtualizada) return res.status(404).json({ mensagem: 'Peça não encontrada para atualização.' }); 
            return res.status(200).json(pecaAtualizada);
        } catch (error) {
            // Mudança na mensagem de erro
            return res.status(500).json({ erro: 'Erro ao atualizar peça.', detalhes: error.message }); 
        }
    },
    async delete(req, res) {
        try {
            const { id } = req.params;
            // Mudança: Chamada de método
            const linhasDeletadas = await Peca.deletar(id); 
            // Mudança na mensagem de não encontrado
            if (linhasDeletadas === 0) return res.status(404).json({ mensagem: 'Peça não encontrada para exclusão.' }); 
            return res.status(200).json({mensagem:"Excluído com sucesso"});
        } catch (error) {
            // Mudança na mensagem de erro
            return res.status(500).json({ erro: 'Erro ao deletar peça.', detalhes: error.message });
        }
    }
};

// Mudança: exportar pecaController
export default pecaController;