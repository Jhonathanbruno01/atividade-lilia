// routes/orders.js
const express = require('express');
const router = express.Router();
const db = require('../config/db');

// Create order: expects { customer_id (optional), items: [{ product_id, qty }], billing_address_id?, shipping_address_id? }
router.post('/', async (req, res) => {
  const conn = await db.getConnection();
  try {
    const { customer_id, items, billing_address_id, shipping_address_id } = req.body;
    if (!items || !Array.isArray(items) || items.length === 0) return res.status(400).json({ error: 'items_required' });

    await conn.beginTransaction();

    // calculate subtotal and validate stock
    let subtotal = 0;
    for (const it of items) {
      const [p] = await conn.query('SELECT id, price, stock FROM products WHERE id=? FOR UPDATE', [it.product_id]);
      if (!p.length) throw new Error('product_not_found:' + it.product_id);
      if (p[0].stock < it.qty) throw new Error('out_of_stock:' + it.product_id);
      subtotal += Number(p[0].price) * Number(it.qty);
    }

    const [orderRes] = await conn.query(
      'INSERT INTO orders (customer_id,status,subtotal,discount,shipping,total,billing_address_id,shipping_address_id,created_at) VALUES (?,?,?,?,?,?,?,?,NOW())',
      [customer_id || null, 'pending', subtotal, 0.00, 0.00, subtotal, billing_address_id || null, shipping_address_id || null]
    );
    const orderId = orderRes.insertId;

    for (const it of items) {
      const [p] = await conn.query('SELECT price, stock FROM products WHERE id=? FOR UPDATE', [it.product_id]);
      const price = p[0].price;
      await conn.query(
        'INSERT INTO order_items (order_id,product_id,qty,price,total_price,created_at) VALUES (?,?,?,?,?,NOW())',
        [orderId, it.product_id, it.qty, price, Number(price) * Number(it.qty)]
      );
      await conn.query('UPDATE products SET stock = stock - ? WHERE id=?', [it.qty, it.product_id]);
      await conn.query('INSERT INTO inventory_log (product_id, change_qty, reason, created_at) VALUES (?,?,?,NOW())', [it.product_id, -it.qty, 'sale']);
    }

    await conn.commit();
    res.json({ orderId });
  } catch (err) {
    await conn.rollback();
    console.error(err);
    const msg = err.message || 'error';
    if (msg.startsWith('out_of_stock')) return res.status(400).json({ error: 'out_of_stock', detail: msg });
    if (msg.startsWith('product_not_found')) return res.status(404).json({ error: 'product_not_found', detail: msg });
    res.status(500).json({ error: 'db_error', detail: msg });
  } finally {
    conn.release();
  }
});

// Get order by id
router.get('/:id', async (req, res) => {
  try {
    const id = req.params.id;
    const [rows] = await db.query('SELECT * FROM orders WHERE id=?', [id]);
    if (!rows.length) return res.status(404).json({ error: 'not_found' });
    const order = rows[0];
    const [items] = await db.query('SELECT oi.*, p.name FROM order_items oi JOIN products p ON p.id = oi.product_id WHERE oi.order_id=?', [id]);
    order.items = items;
    res.json(order);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'db_error' });
  }
});

module.exports = router;
