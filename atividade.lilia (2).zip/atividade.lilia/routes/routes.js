import { Router } from 'express';
// Mudança: importação e nome do controller
import pecaController from '../controllers/controllers.js'; 

const router = Router();

// Mudança: Rotas de /sneakers para /pecas
router.get('/pecas', pecaController.listAll);
router.get('/pecas/:id', pecaController.listOne);
router.post('/pecas', pecaController.create);
router.put('/pecas/:id', pecaController.update);
router.delete('/pecas/:id', pecaController.delete);

export default router;