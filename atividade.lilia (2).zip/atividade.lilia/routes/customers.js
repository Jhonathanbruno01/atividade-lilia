// routes/customers.js
const express = require('express');
const router = express.Router();
const db = require('../config/db');

// POST /api/customers
router.post('/', async (req, res) => {
  try {
    const { first_name, last_name, email, phone } = req.body;
    const [result] = await db.query(
      'INSERT INTO customers (first_name,last_name,email,phone,created_at) VALUES (?,?,?,?,NOW())',
      [first_name, last_name, email, phone]
    );
    res.json({ id: result.insertId });
  } catch (err) {
    if (err && err.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'email_exists' });
    console.error(err);
    res.status(500).json({ error: 'db_error' });
  }
});

module.exports = router;
