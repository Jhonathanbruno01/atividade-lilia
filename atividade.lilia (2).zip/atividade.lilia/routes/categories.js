// routes/categories.js
const express = require('express');
const router = express.Router();
const db = require('../config/db');

router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT id, name, slug, description FROM categories');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'db_error' });
  }
});

router.post('/', async (req, res) => {
  try {
    const { name, slug, description } = req.body;
    const [result] = await db.query(
      'INSERT INTO categories (name,slug,description,created_at) VALUES (?,?,?,NOW())',
      [name, slug, description]
    );
    res.json({ id: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'db_error' });
  }
});

module.exports = router;
