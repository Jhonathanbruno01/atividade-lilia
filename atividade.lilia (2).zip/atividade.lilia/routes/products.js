// routes/products.js
const express = require('express');
const router = express.Router();
const db = require('../config/db');

// GET /api/products
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT id, sku, name, slug, description, price, stock, category_id FROM products');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'db_error' });
  }
});

// GET /api/products/:id
router.get('/:id', async (req, res) => {
  try {
    const id = req.params.id;
    const [rows] = await db.query('SELECT * FROM products WHERE id = ?', [id]);
    if (!rows.length) return res.status(404).json({ error: 'not_found' });
    const product = rows[0];
    const [images] = await db.query('SELECT url, alt_text, is_primary FROM product_images WHERE product_id = ? ORDER BY sort_order', [id]);
    product.images = images;
    res.json(product);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'db_error' });
  }
});

// POST /api/products
router.post('/', async (req, res) => {
  try {
    const { sku, name, slug, description, price, stock, category_id } = req.body;
    const [result] = await db.query(
      'INSERT INTO products (sku,name,slug,description,price,stock,category_id,created_at) VALUES (?,?,?,?,?,?,?,NOW())',
      [sku, name, slug, description, price || 0, stock || 0, category_id || null]
    );
    res.json({ id: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'db_error' });
  }
});

// PUT /api/products/:id
router.put('/:id', async (req, res) => {
  try {
    const id = req.params.id;
    const { sku, name, slug, description, price, stock, category_id } = req.body;
    await db.query(
      'UPDATE products SET sku=?,name=?,slug=?,description=?,price=?,stock=?,category_id=?,updated_at=NOW() WHERE id=?',
      [sku, name, slug, description, price || 0, stock || 0, category_id || null, id]
    );
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'db_error' });
  }
});

// DELETE /api/products/:id
router.delete('/:id', async (req, res) => {
  try {
    const id = req.params.id;
    await db.query('DELETE FROM products WHERE id=?', [id]);
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'db_error' });
  }
});

module.exports = router;
